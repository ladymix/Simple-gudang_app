// Contoh JavaScript kustom
console.log("Aplikasi Gudang siap digunakan!");